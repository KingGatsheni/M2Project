admin login 

username = admin
password = pass

manager login
username  = manager
password = pass